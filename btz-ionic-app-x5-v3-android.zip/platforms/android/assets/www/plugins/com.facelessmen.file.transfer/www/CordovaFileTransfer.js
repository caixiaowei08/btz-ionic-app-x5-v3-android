cordova.define("com.facelessmen.file.transfer.CordovaFileTransfer", function(require, exports, module) {
var exec = require('cordova/exec');

exports.download = function (id,source,target,success, error) {
    exec(success, error, 'CordovaFileTransfer', 'download', [id,source,target]);
};

exports.onProgress = function (success, error) {
    exec(success, error, 'CordovaFileTransfer', 'onProgress', []);
};

exports.stop = function (id,success, error) {
    exec(success, error, 'CordovaFileTransfer', 'stop', [id]);
};

exports.delete = function (id,source,target,success, error) {
    exec(success, error, 'CordovaFileTransfer', 'delete', [id,source,target]);
};

exports.checkFileIsExist = function (id,target,success, error) {
    exec(success, error, 'CordovaFileTransfer', 'checkFileIsExist', [id,target]);
};

exports.checkVideoItemState = function (id,target,success, error) {
    exec(success, error, 'CordovaFileTransfer', 'checkVideoItemState', [id,target]);
};

exports.findVideoList = function (target,success, error) {
    exec(success, error, 'CordovaFileTransfer', 'findVideoList', [target]);
};

});
