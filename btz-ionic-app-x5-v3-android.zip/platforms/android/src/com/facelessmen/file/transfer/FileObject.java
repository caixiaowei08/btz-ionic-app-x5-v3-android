package com.facelessmen.file.transfer;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**
 * Created by User on 2018/4/3.
 */

public class FileObject implements Serializable {

  private String fileName;

  private String lastModifyTime;

  public FileObject(String fileName, String lastModifyTime) {
    this.fileName = fileName;
    this.lastModifyTime = lastModifyTime;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getLastModifyTime() {
    return lastModifyTime;
  }

  public void setLastModifyTime(String lastModifyTime) {
    this.lastModifyTime = lastModifyTime;
  }

}
