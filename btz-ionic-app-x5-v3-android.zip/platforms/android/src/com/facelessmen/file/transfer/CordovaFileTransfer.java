package com.facelessmen.file.transfer;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;

import org.apache.cordova.LOG;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/**
 * This class echoes a string called from JavaScript.
 */
public class CordovaFileTransfer extends CordovaPlugin {

  private static final String LOG_TAG = "CordovaFileTransfer";

  @Override
  public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
    if (action.equals("download")) {
      String id = args.getString(0);
      String source = args.getString(1);
      String target = args.getString(2).replace("file://", "");
      FileTransferObject fileTransferObject = new FileTransferObject();
      fileTransferObject.setId(id);
      fileTransferObject.setSource(source);
      fileTransferObject.setTarget(target);
      long localFileSize = FileUtils.getLocalFileSize(fileTransferObject.getTarget() + id + ".mp4");

      if (localFileSize > 0) {

        fileTransferObject.setState(FileTransferObject.DONE);
        //fileTransferObject.setMsg("file was downloaded !");
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.ERROR, "fileExist"));
        return false;
      }
      this.download(fileTransferObject, callbackContext);
      return true;
    } else if (action.equals("onProgress")) {
      this.onProgress(callbackContext);
      return true;
    } else if (action.equals("stop")) {
      String id = args.getString(0);
      this.stop(id, callbackContext);
      return true;
    } else if (action.equals("delete")) {
      String id = args.getString(0);
      String source = args.getString(1);
      String target = args.getString(2).replace("file://", "");
      FileTransferObject fileTransferObject = new FileTransferObject();
      fileTransferObject.setId(id);
      fileTransferObject.setSource(source);
      fileTransferObject.setTarget(target);
      delete(fileTransferObject, callbackContext);
      return true;
    } else if (action.equals("checkFileIsExist")) {
      String id = args.getString(0);
      String target = args.getString(1).replace("file://", "");
      FileTransferObject fileTransferObject = new FileTransferObject();
      if (FileUtils.checkFileIsExist(target + id + ".mp4")) {
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "Y"));
      } else {
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "N"));
      }
      return true;
    } else if (action.equals("checkVideoItemState")) {
      String id = args.getString(0);
      String target = args.getString(1).replace("file://", "");
      this.checkVideoItemState(id, target, callbackContext);
      return true;
    } else if (action.equals("findVideoList")) {
      String target = args.getString(0).replace("file://", "");
      String[] fileNameList = FileUtils.findAllFilesInPath(target);
      JSONObject jsonObject = new JSONObject();
      JSONArray videoList = new JSONArray();
      for (String fileName : fileNameList) {
        if (fileName.contains(".mp4")) {
          JSONObject jsonObjectItem = new JSONObject();
          jsonObjectItem.put("fileName", fileName);
          jsonObjectItem.put("lastModifyTime", FileUtils.getFileModifyTime(target + fileName));
          jsonObjectItem.put("id", fileName.replace(".mp4", ""));
          videoList.put(jsonObjectItem);
        }
      }
      jsonObject.put("videoList", videoList);
      callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, jsonObject));
      return true;
    }
    return false;
  }

  //新增
  private void download(FileTransferObject fileTransferObject, CallbackContext callbackContext) {
    MutiThreadFileTransferManager mutiThreadFileTransferManager = MutiThreadFileTransferManager.getInstance();
    try {
      fileTransferObject = mutiThreadFileTransferManager.addFileTransferObjectToQueue(fileTransferObject);
      if (fileTransferObject.getState() == FileTransferObject.EXIST) { //
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.ERROR, "exist"));
        return;
      }
      //返回陈功
      if (!mutiThreadFileTransferManager.isAlive()) {
        mutiThreadFileTransferManager.start();
      }
      callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "success"));
    } catch (InterruptedException ie) {
      callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.ERROR, "exception"));
    }
  }

  //监听
  private void onProgress(CallbackContext callbackContext) {
    MutiThreadFileTransferManager mutiThreadFileTransferManager = MutiThreadFileTransferManager.getInstance();
    mutiThreadFileTransferManager.setCallbackContext(callbackContext);
  }

  //停止
  private void stop(String id, CallbackContext callbackContext) {
    MutiThreadFileTransferManager mutiThreadFileTransferManager = MutiThreadFileTransferManager.getInstance();
    mutiThreadFileTransferManager.stopFileDownloadById(id, callbackContext);
  }

  private void delete(FileTransferObject fileTransferObject, CallbackContext callbackContext) {
    MutiThreadFileTransferManager mutiThreadFileTransferManager = MutiThreadFileTransferManager.getInstance();
    mutiThreadFileTransferManager.deleteDownloadFile(fileTransferObject, callbackContext);
  }

  private void checkVideoItemState(String id, String target, CallbackContext callbackContext) {
    MutiThreadFileTransferManager mutiThreadFileTransferManager = MutiThreadFileTransferManager.getInstance();

    if (FileUtils.checkFileIsExist(target + id + ".mp4")) { //本地已下载
      callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "done"));
      return;
    }

    for (FileTransferObject fileTransferObject : mutiThreadFileTransferManager.getFileTransferObjectList()) {
      if (fileTransferObject.getId().equals(id)) {
        if (fileTransferObject.getState() == FileTransferObject.DOWNLOAD) {
          callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "download"));
          return;
        } else if (fileTransferObject.getState() == FileTransferObject.WAITING) {
          callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "wait"));
          return;
        }
      }
    }

    if (FileUtils.checkFileIsExist(target + id + ".temp")) { //本地已下载
      callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "stop"));
      return;
    }

    callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, "none"));
  }

}
