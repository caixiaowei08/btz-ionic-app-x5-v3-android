package com.facelessmen.file.transfer;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.LOG;
import org.apache.cordova.PluginResult;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Created by User on 2018/3/28.
 */

public class MutiThreadFileTransferManager extends Thread {

  private static final String LOG_TAG = "MutiThreadFileTransferManager";

  private static MutiThreadFileTransferManager instance = null;

  private CallbackContext callbackContext;

  private MutiThreadFileTransferManager() {
  }

  public static synchronized MutiThreadFileTransferManager getInstance() {
    if (instance == null) {
      instance = new MutiThreadFileTransferManager();
    }
    return instance;
  }

  //等待队列
  LinkedBlockingQueue<FileTransferObject> fileTransferObjectLinkedBlockingQueue = new LinkedBlockingQueue<FileTransferObject>();

  //线程队列
  LinkedBlockingQueue<SingleFileTransferThread> singleFileTransferThreadLinkedBlockingQueue = new LinkedBlockingQueue<SingleFileTransferThread>();

  //线程队列
  List<FileTransferObject> fileTransferObjectList = new ArrayList<FileTransferObject>();


  //最大的下载线程数3
  private final static int MAX_DOWNLOAD_MUN = 3;

  /**
   * 添加下载对象FileTransferObject
   */
  public FileTransferObject addFileTransferObjectToQueue(FileTransferObject fileTransferObject) throws InterruptedException {
    for (FileTransferObject fileTransferObjectInQueue : fileTransferObjectLinkedBlockingQueue) {
      if (fileTransferObjectInQueue.getId().equals(fileTransferObject.getId())) {
        fileTransferObject.setState(FileTransferObject.EXIST);
        return fileTransferObject;
      }
    }

    for (SingleFileTransferThread singleFileTransferThread : singleFileTransferThreadLinkedBlockingQueue) {
      if (singleFileTransferThread.getFileTransferObject().getId().equals(fileTransferObject.getId())) {
        fileTransferObject.setState(FileTransferObject.EXIST);
        return fileTransferObject;
      }
    }

    for (int i = 0; i < fileTransferObjectList.size(); i++) {
      if (fileTransferObjectList.get(i).getId() == fileTransferObject.getId()) {
        fileTransferObjectList.remove(fileTransferObjectList.get(i));
      }
    }

    fileTransferObject.setState(FileTransferObject.WAITING); //等待
    fileTransferObjectLinkedBlockingQueue.put(fileTransferObject);
    fileTransferObjectList.add(fileTransferObject);
    //添加监控
    return fileTransferObject;
  }


  @Override
  public void run() {
    while (true) {
      try {
        Thread.sleep(500);
      } catch (Exception e) {
        e.printStackTrace();
      }
      if (fileTransferObjectLinkedBlockingQueue.size() > 0 && singleFileTransferThreadLinkedBlockingQueue.size() < MAX_DOWNLOAD_MUN) {
        FileTransferObject fileTransferObject = fileTransferObjectLinkedBlockingQueue.poll();
        if (fileTransferObject.getState() == FileTransferObject.WAITING) { //只有等待的才能 进行下载
          SingleFileTransferThread singleFileTransferThread = new SingleFileTransferThread(singleFileTransferThreadLinkedBlockingQueue, fileTransferObject);
          singleFileTransferThread.start();
          try {
            singleFileTransferThreadLinkedBlockingQueue.put(singleFileTransferThread);
          } catch (InterruptedException ie) {
            ie.printStackTrace();
          }
        }
      }

      //监听部分
      if (callbackContext != null) {
        for (int i = 0; i < fileTransferObjectList.size(); i++) {
          try {
            PluginResult pluginResult = new PluginResult(PluginResult.Status.OK, fileTransferObjectList.get(i).toJSONObject());
            pluginResult.setKeepCallback(true);
            callbackContext.sendPluginResult(pluginResult);
            if (!(fileTransferObjectList.get(i).getState() == FileTransferObject.WAITING || fileTransferObjectList.get(i).getState() == FileTransferObject.DOWNLOAD)) {//下载完毕的移除 异常移除
              fileTransferObjectList.remove(fileTransferObjectList.get(i));
            }
          } catch (JSONException je) {
            LOG.d(LOG_TAG, "JSONException:" + je.getMessage());
          }
        }
      }
    }
  }

  public CallbackContext getCallbackContext() {
    return callbackContext;
  }

  public void setCallbackContext(CallbackContext callbackContext) {
    this.callbackContext = callbackContext;
  }

  public void stopFileDownloadById(String id, CallbackContext callbackContex) {
    for (FileTransferObject fileTransferObject : fileTransferObjectList) {
      if (fileTransferObject.getId().equals(id)) {
        fileTransferObject.setState(FileTransferObject.STOP);
        fileTransferObjectLinkedBlockingQueue.remove(fileTransferObject);
      }
    }
    callbackContex.sendPluginResult(new PluginResult(PluginResult.Status.OK));
  }

  public void deleteDownloadFile(FileTransferObject fileTransferObject, CallbackContext callbackContext) {
    //下载状态 必须先停止
    for (FileTransferObject fileTransferObject1 : fileTransferObjectList) {
      if (fileTransferObject1.getId().equals(fileTransferObject.getId())) {
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.ERROR, "downloading"));
        return;
      }
    }
    if (FileUtils.deleteFile(fileTransferObject.getTarget() + fileTransferObject.getId() + ".temp") &&
      FileUtils.deleteFile(fileTransferObject.getTarget() + fileTransferObject.getId() + ".mp4")
      ) {
      callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK));
    } else {
      callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.ERROR, "exception"));
    }
  }

  public List<FileTransferObject> getFileTransferObjectList() {
    return fileTransferObjectList;
  }

}
