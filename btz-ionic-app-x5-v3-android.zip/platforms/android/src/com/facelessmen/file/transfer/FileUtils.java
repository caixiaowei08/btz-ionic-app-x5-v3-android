package com.facelessmen.file.transfer;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by User on 2018/3/28.
 */

public class FileUtils {
  public static long getLocalFileSize(String target) {
    File file = new File(target);
    if (file.exists() && file.isFile()) {
      return file.length();
    } else {
      return -1;
    }
  }

  public static long getRemoteFileSize(String source) throws MalformedURLException, IOException {
    URL url = new URL(source);
    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
    httpURLConnection.setRequestProperty("User-Agent", "NetFox");
    int responseCode = httpURLConnection.getResponseCode();
    if (responseCode == 200) {
      return httpURLConnection.getContentLength();
    } else {
      return -1;
    }
  }

  public static boolean renameTempToMp4(String target) {
    File file = new File(target);
    if (file.exists() && file.isFile()) {
      return file.renameTo(new File(target.replace(".temp", ".mp4")));
    } else {
      return false;
    }
  }

  public static boolean deleteFile(String target) {
    File file = new File(target);
    if (file.exists() && file.isFile()) {
      return file.delete();
    } else {
      return true;
    }
  }

  public static boolean checkFileIsExist(String target) {
    File file = new File(target);
    if (file.exists() && file.isFile()) {
      return true;
    } else {
      return false;
    }
  }

  public static String[] findAllFilesInPath(String target) {
    File file = new File(target);
    if (file.exists() && file.isDirectory()) {
      return file.list();
    } else {
      return new String[0];
    }
  }

  public static String getFileModifyTime(String target) {
    File file = new File(target);
    if (file.exists() && file.isFile()) {
      Calendar cal = Calendar.getInstance();
      cal.setTimeInMillis(file.lastModified());
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      return formatter.format(cal.getTime());
    } else {
      return "-";
    }
  }
}
