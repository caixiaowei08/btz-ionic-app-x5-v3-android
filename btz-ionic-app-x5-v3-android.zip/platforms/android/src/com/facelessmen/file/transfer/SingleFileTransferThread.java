package com.facelessmen.file.transfer;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.cordova.LOG;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * Created by User on 2018/3/28.
 */

public class SingleFileTransferThread extends Thread {

  private static final String LOG_TAG = "SingleFileTransferThread";

  private LinkedBlockingQueue<SingleFileTransferThread> singleFileTransferThreadLinkedBlockingQueue;

  private FileTransferObject fileTransferObject;

  public SingleFileTransferThread(LinkedBlockingQueue<SingleFileTransferThread> singleFileTransferThreadLinkedBlockingQueue, FileTransferObject fileTransferObject) {
    this.singleFileTransferThreadLinkedBlockingQueue = singleFileTransferThreadLinkedBlockingQueue;
    this.fileTransferObject = fileTransferObject;
  }

  @Override
  public void run() {
    //文件总大小
    long fileRemoteTotalSize = 0;
    long fileLocalLoadedSize = 0;
    try {
      fileRemoteTotalSize = FileUtils.getRemoteFileSize(fileTransferObject.getSource());
      fileTransferObject.setTotal(fileRemoteTotalSize);
    } catch (IOException ie) {
      //fileTransferObject.setMsg("net work error !");
      fileTransferObject.setState(FileTransferObject.ERROR);
      fileTransferObject.setMsg("netError!");
      singleFileTransferThreadLinkedBlockingQueue.remove(this);
      return;
    }

    fileLocalLoadedSize = FileUtils.getLocalFileSize(fileTransferObject.getTarget() + fileTransferObject.getId() + ".temp");
    if (fileLocalLoadedSize >= 0) {
      fileTransferObject.setLoaded(fileLocalLoadedSize);
    } else {
      fileTransferObject.setLoaded(0);
    }
    URL url = null;
    HttpURLConnection httpURLConnection = null;
    RandomAccessFile randomAccessFile = null;
    try {
      url = new URL(fileTransferObject.getSource());
      httpURLConnection = (HttpURLConnection) url.openConnection();
      httpURLConnection.setRequestProperty("User-Agent", "NetFox");
      if (fileLocalLoadedSize > 0) {
        httpURLConnection.setRequestProperty("Range", "bytes=" + fileLocalLoadedSize + "-");
      }

      int responseCode = httpURLConnection.getResponseCode();

      long currentLocalSize = 0;
      if (responseCode == 200) {
        currentLocalSize = 0;
      } else if (responseCode == 206) {
        currentLocalSize = fileTransferObject.getLoaded();
      } else if (responseCode == 216) {
        if(FileUtils.checkFileIsExist(fileTransferObject.getTarget() + fileTransferObject.getId() + ".temp")){
          if (FileUtils.renameTempToMp4(fileTransferObject.getTarget() + fileTransferObject.getId() + ".temp")) {
            fileTransferObject.setState(FileTransferObject.DONE);//已下载完成
            singleFileTransferThreadLinkedBlockingQueue.remove(this);
          } else {
            fileTransferObject.setState(FileTransferObject.ERROR);
            fileTransferObject.setMsg("changeNameError");
            singleFileTransferThreadLinkedBlockingQueue.remove(this);
          }
        }
        return;
      } else {
        fileTransferObject.setState(FileTransferObject.ERROR);
        singleFileTransferThreadLinkedBlockingQueue.remove(this);
        httpURLConnection.disconnect();
        return;
      }

      InputStream inputStream = httpURLConnection.getInputStream();
      randomAccessFile = new RandomAccessFile(fileTransferObject.getTarget() + fileTransferObject.getId() + ".temp", "rw");
      if (fileLocalLoadedSize >= 0) {
        randomAccessFile.seek(fileLocalLoadedSize);
      } else {
        randomAccessFile.seek(0);
      }
      byte[] fileBuffer = new byte[1024];
      int readPosition;
      fileTransferObject.setState(FileTransferObject.DOWNLOAD);//正在下载标识
      while ((readPosition = inputStream.read(fileBuffer, 0, 1024)) > 0) {
        randomAccessFile.write(fileBuffer, 0, readPosition);
        currentLocalSize = currentLocalSize + readPosition;
        fileTransferObject.setLoaded(currentLocalSize);
        // LOG.d(LOG_TAG, "download :" + fileTransferObject.getId() + " loaded:" + currentLocalSize);
        // fileTransferObject.setMsg("downloading");
        if (fileTransferObject.getState() == FileTransferObject.STOP) {
          singleFileTransferThreadLinkedBlockingQueue.remove(this);
          return;
        }
      }
      if (currentLocalSize == fileRemoteTotalSize) { //下载完毕 并且文件大小和网络大小一致 方可确认为 正常下载完毕
        if (FileUtils.renameTempToMp4(fileTransferObject.getTarget() + fileTransferObject.getId() + ".temp")) {
          fileTransferObject.setState(FileTransferObject.DONE);//已下载完成
          singleFileTransferThreadLinkedBlockingQueue.remove(this);
        } else {
          fileTransferObject.setState(FileTransferObject.ERROR);
          fileTransferObject.setMsg("changeFileNameError");
          singleFileTransferThreadLinkedBlockingQueue.remove(this);
        }
      } else {
        fileTransferObject.setState(FileTransferObject.ERROR);
        singleFileTransferThreadLinkedBlockingQueue.remove(this);
        fileTransferObject.setMsg("tryAgainError");
      }
    } catch (MalformedURLException mue) {
      fileTransferObject.setState(FileTransferObject.ERROR);
      singleFileTransferThreadLinkedBlockingQueue.remove(this);
      fileTransferObject.setMsg("urlError");
      LOG.d(LOG_TAG, "MalformedURLException:" + mue.getMessage());
    } catch (IOException ie) {
      fileTransferObject.setState(FileTransferObject.ERROR);
      fileTransferObject.setMsg("netOrFileError");
      singleFileTransferThreadLinkedBlockingQueue.remove(this);
      LOG.d(LOG_TAG, "IOException:" + ie.getMessage());
    } finally {
      httpURLConnection.disconnect();
      try {
        if (randomAccessFile != null) {
          randomAccessFile.close();
        }
      } catch (IOException ie) {
        LOG.d(LOG_TAG, "IOException:" + ie.getMessage());
        fileTransferObject.setState(FileTransferObject.ERROR);
        fileTransferObject.setMsg("FileSaveError");
        singleFileTransferThreadLinkedBlockingQueue.remove(this);

      }
    }
  }

  public FileTransferObject getFileTransferObject() {
    return fileTransferObject;
  }

  public void setFileTransferObject(FileTransferObject fileTransferObject) {
    this.fileTransferObject = fileTransferObject;
  }
}
