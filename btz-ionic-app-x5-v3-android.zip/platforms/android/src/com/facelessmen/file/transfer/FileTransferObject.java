package com.facelessmen.file.transfer;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**
 * Created by User on 2018/3/28.
 */

public class FileTransferObject implements Serializable {


  private String id = "0";

  private String source = "";

  private String target = "";

  /**
   * 0-等待 1-正在下载 2-下载完成 3-已经存在 4-网络异常
   */
  private int state = 0;

  public final static int WAITING = 0;

  public final static int DOWNLOAD = 1;

  public final static int DONE = 2;

  public final static int EXIST = 3;

  public final static int ERROR = 4;

  public final static int STOP = 5;

  private String msg = "-";

  private long total = 0;

  private long loaded = 0;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getTarget() {
    return target;
  }

  public void setTarget(String target) {
    this.target = target;
  }

  public int getState() {
    return state;
  }

  public void setState(int state) {
    this.state = state;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }

  public long getTotal() {
    return total;
  }

  public void setTotal(long total) {
    this.total = total;
  }

  public long getLoaded() {
    return loaded;
  }

  public void setLoaded(long loaded) {
    this.loaded = loaded;
  }

  public JSONObject toJSONObject() throws JSONException {
    return new JSONObject(
      "{" +
        "id:" + id +
        ",state:" + state +
        ",msg:" +  msg +
        ",total:" + total +
        ",loaded:" + loaded +
        "}");
  }

}
